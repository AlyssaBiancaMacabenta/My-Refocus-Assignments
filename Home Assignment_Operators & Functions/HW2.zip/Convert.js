function convertToKelvin(tempCelsius){
    let tempKelvin = tempCelsius + 273.15;
    return tempKelvin;
}

console.log(convertToKelvin(84))

function convertToKelvin(tempFahrenheit){
    let tempCelsius = (tempFahrenheit - 32) / 1.8;
    let tempKelvin = tempCelsius + 273;
    return tempKelvin;
}

console.log(convertToKelvin(95))
