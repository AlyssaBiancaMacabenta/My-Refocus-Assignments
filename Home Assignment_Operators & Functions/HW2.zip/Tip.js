function calculateTip(myParameter){
    let totalTip = myParameter / 10;
    return totalTip;
}

console.log(calculateTip(3500))