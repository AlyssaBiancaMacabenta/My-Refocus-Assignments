const dishMenu = {
    "dishes": [
            {
                dishID: "first",
                dishName: "Adobo",
                dishPrice: "₱500",
                ingredients: ["pork", " soy sauce", " vinegar"],
            },
            {
                dishID: "second",
                dishName: "Sinigang",
                dishPrice: "₱500",
                ingredients: ["pork", " tomato", " onion"],
            },
            {
                dishID: "third",
                dishName: "Tinola",
                dishPrice: "₱500",
                ingredients: ["chicken", " bottle gourd", " ginger"],
            }
        ],
    }