const bankAccount = {
    
    bankAccountID : "aleezus",
    accountNumber : "0-6092-022",
    credentials :
        { 

            "username" : "aleezus", 
            "password" : "ittehgaps1", 
            "pin" : "6465" 

        },
    balance : 1000,
    createdAt : "20/10/2022",

}
